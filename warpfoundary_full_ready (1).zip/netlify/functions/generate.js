exports.handler = async (event) => {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ error:"Method Not Allowed. Use POST." }) };
    }
    const body = JSON.parse(event.body || "{}");
    const idea = body.idea || "No idea provided";
    const buildType = body.buildType || "Web App";
    const features = body.features || {};
    return {
      statusCode: 200,
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({
        mode: "demo",
        name: "WarpFoundary DemoCo",
        oneLiner: "From idea to MVP in one warp-speed prompt.",
        input: { idea, buildType, features },
        mvp: ["Landing page (HTML/CSS/JS)", "Serverless API", "Pitch deck stub"].concat(
          features.revenue?["Revenue snapshot"]:[],
          features.tm?["TM/domain check"]:[],
          features.radar?["Competitor radar"]:[]
        ),
        nextSteps: ["Add API keys to go live", "Connect domain", "Ship beta"]
      })
    };
  } catch (err) {
    return { statusCode: 500, headers: { "Content-Type":"application/json" }, body: JSON.stringify({ error: String(err) }) };
  }
};
